def plugin_version():
    return 1
