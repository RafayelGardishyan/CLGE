# Always Needed
from . import setup

# Your imports
from .plugin import plugin_version as Test_PluginVer